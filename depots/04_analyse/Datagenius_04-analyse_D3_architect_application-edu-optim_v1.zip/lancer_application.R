# Lance EDU-OPTIM BURKINA dans le navigateur.
# Dans RStudio : ouvrez EDU_OPTIM_BURKINA.Rproj puis exécutez ce fichier (Source).
shiny::runApp(".", launch.browser = TRUE)
