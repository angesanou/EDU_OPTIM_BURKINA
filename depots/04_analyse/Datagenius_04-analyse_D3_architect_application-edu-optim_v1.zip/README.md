# EDU-OPTIM BURKINA

**Plateforme d'aide à la décision pour la planification et l'optimisation des ressources éducatives** : préscolaire, primaire, post-primaire et secondaire, 13 anciennes régions, 45 provinces, communes et établissements.

> **DONNÉES SYNTHÉTIQUES — ENVIRONNEMENT DE DÉMONSTRATION — AUCUNE STATISTIQUE OFFICIELLE.**
> Toutes les valeurs fournies sont générées par `scripts/01_generer_donnees_synthetiques.R` (graine fixe). L'application lit le **format EXX_01** : vos données réelles s'y branchent sans modifier le code (voir [Remplacer les données](documentation/remplacer_donnees.md)).

## Démarrage rapide

```r
# RStudio : ouvrir EDU_OPTIM_BURKINA.Rproj, puis
source("scripts/00_installer_packages.R")                                   # une fois
source("scripts/01_generer_donnees_synthetiques.R", encoding = "UTF-8")     # environ 2 minutes
shiny::runApp()                                                             # ou double-clic sur LANCER_EDU_OPTIM.bat
```

Connexion de démonstration : `national` / `Demo-National-2026`. Autres comptes : [installation](documentation/installation.md).

## Les 14 modules

| # | Module | Contenu |
|---|---|---|
| 1 | Accueil | présentation, objectifs, indicateurs clés, alertes automatiques, synthèse rédigée, accès rapide |
| 2 | Tableau de bord | 12 KPI calculés avec évolution annuelle ; répartition par cycle ; comparaison des 13 régions ; tendances ; urbain/rural ; coût des déficits ; classement |
| 3 | Données et sources | jeux chargés, observations, manquants, doublons, identifiants, historique des traitements, dictionnaire |
| 4 | Diagnostic | déficits par région, province, commune ou établissement : salles, enseignants, tables-bancs, latrines, eau, électricité, cantines |
| 5 | Indice IMDE | 5 dimensions, 16 indicateurs ; carte, classement, profils ; 6 variantes méthodologiques ; sensibilité de Dirichlet |
| 6 | Cartographie | choroplèthes, établissements, densité hexagonale, accessibilité, Moran global, LISA |
| 7 | Économétrie | MCO, effets fixes, effets aléatoires, double effets fixes ; Hausman, Breusch-Pagan, Wooldridge, Pesaran ; VIF ; bootstrap par grappes |
| 8 | Prévisions | 6 méthodes, backtesting, intervalles 80/95 %, besoins à l'horizon |
| 9 | Priorisation | TOPSIS à 7 critères pondérables, contributions, classement national et régional, sensibilité |
| 10 | Optimisation | programme linéaire sous budget, disponibilités, équité (max-min) et plancher ; IMDE avant/après |
| 11 | Simulations | 6 scénarios prédéfinis + 1 personnalisé ; redéploiement des enseignants (problème de transport) |
| 12 | Rapports | rapport exécutif PDF, fiche territoriale PDF, Excel, CSV, graphique PNG, carte PNG |
| 13 | Documentation | méthodologie, formules, normes, technique, versions |
| 14 | Utilisateurs | profils national, régional et provincial ; périmètres appliqués côté serveur ; création de comptes |

## Structure

Voir la [documentation technique](documentation/documentation_technique.md). En résumé :

- `R/` : fonctions de calcul, testées ;
- `modules/` : une page par module ;
- `config/config.yml` : le seul fichier à modifier pour changer de source ;
- `data/` : modèle, données synthétiques, données réelles, caches.

## Documentation

- [Guide d'utilisation](documentation/guide_utilisation.md)
- [Méthodologie scientifique](documentation/methodologie_scientifique.md) : formules, hypothèses, limites de chaque indicateur et modèle
- [Documentation technique](documentation/documentation_technique.md)
- [Remplacer par des données réelles](documentation/remplacer_donnees.md)
- [Installation, déploiement, dépannage](documentation/installation.md)

## Comment le projet a été construit

| Étape | Réalisation |
|---|---|
| 1. Architecture | Contrat de données unique = classeur EXX_01. Fonctions pures dans `R/`, interface dans `modules/`, configuration centrale, cache. |
| 2. Données synthétiques | Génération « du bas vers le haut » : profils, démographie, établissements, panel annuel, puis agrégation dans EXX_01. |
| 3. Contrôles | 14 contrôles sur le panel et 4 sur les établissements. Manquants et doublons volontaires pour vérifier qu'ils sont détectés. |
| 4. Design | Système de design CSS local (bleu nuit, pétrole, turquoise), polices système, aucune ressource externe obligatoire. |
| 5-11. Modules et moteurs | Indicateurs, IMDE, économétrie, spatial, prévisions, TOPSIS, programme linéaire, scénarios, rapports. |
| 12. Qualité | Tests `testthat`, documentation, `renv` (script 04), lanceurs. |

**Vérifications effectuées sur le poste de développement (R 4.6.0, Windows)** :

- génération des données : 30 351 établissements, 263 315 lignes établissement × année, 349 communes ;
- contrôles : 4 doublons volontaires détectés ;
- indicateurs ; IMDE (classes de favorable à critique ; corrélations de rang entre variantes ≥ 0,99) ;
- économétrie (Hausman favorable aux effets fixes ; bootstrap) ;
- Moran (I ≈ 0,61, p = 0,001), LISA, accessibilité, densité.

Les modules d'interface ont été écrits ensuite. Ils ont fait l'objet d'une revue statique, mais leur première exécution complète reste à faire sur votre poste : signalez tout message d'erreur.
