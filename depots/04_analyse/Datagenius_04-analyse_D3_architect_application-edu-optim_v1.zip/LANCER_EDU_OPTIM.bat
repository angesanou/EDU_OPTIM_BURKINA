@echo off
REM Lance EDU-OPTIM BURKINA sans ouvrir RStudio (double-clic).
setlocal
set "RS="
for /d %%d in ("C:\Program Files\R\R-*") do set "RS=%%d\bin\Rscript.exe"
if not defined RS for /d %%d in ("%LOCALAPPDATA%\Programs\R\R-*") do set "RS=%%d\bin\Rscript.exe"
if not defined RS (echo R introuvable. Installez R depuis https://cran.r-project.org & pause & exit /b 1)
cd /d "%~dp0"
echo Demarrage d'EDU-OPTIM BURKINA... Fermez cette fenetre pour arreter l'application.
"%RS%" -e "shiny::runApp('.', launch.browser = TRUE)"
pause
